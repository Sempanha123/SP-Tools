<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('article_tag', function (Blueprint $table) {
            $table->id();

            $table
                ->foreignId('article_id')
                ->constrained('articles')
                ->cascadeOnDelete()
                ->cascadeOnUpdate();

            $table
                ->foreignId('tag_id')
                ->constrained('tags')
                ->cascadeOnDelete()
                ->cascadeOnUpdate();

            $table->timestamps();

            $table->unique([
                'article_id',
                'tag_id',
            ]);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('article_tag');
    }
};